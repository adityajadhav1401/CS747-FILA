echo "TASK 1"
echo
echo
python3 gridworld.py 0 0 200 task1
echo
echo
echo "TASK 2"
echo
echo
python3 gridworld.py 1 0 200 task2
echo
echo
echo "TASK 3"
echo
echo
python3 gridworld.py 1 1 200 task3